#include <iostream>
#include "bagian isi/Input.h"
#include "bagian isi/Proses.h"
#include "bagian isi/Output.h"
using namespace std;

int main(){
    Input objectInput = Input();
    Proses objectProses = Proses();
    Output objectOutput = Output();
    string nama[100];
    int long nim[100];
    int skor[100];
    objectInput.input(nama, nim, skor);
    objectProses.proses(nama, nim, skor);
    objectOutput.output(nama,nim, skor);
    return 0;
}